
import React from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import './issue.css'

const Addissue = () => {
  // Define the validation schema using Yup
  const validationSchema = Yup.object().shape({
    IssueDescription: Yup.string().required("Issue Description is require"),
    Severity: Yup.string().required("Please select an option from the selector"),
    Status: Yup.string().required("Please select a radio option"),

  });

  // Initial form values
  const initialValues = {
    IssueDescription: "",
    Severity: "",
    Status: "",
  
    

  };

  // Submit handler
//   const handleSubmit = (values) => {
//     // Handle form submission logic here
//     console.log("Form values:", values);
//   };
  const handleSubmit = async (values, { setSubmitting }) => {
    try {
      const response = await fetch("http://localhost:3000/issues", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(values),
      });

      if (!response.ok) {
        throw new Error("Failed to submit the form.");
      }

      // Handle successful submission (e.g., show a success message)
      console.log("Form submitted successfully!");
    } catch (error) {
      // Handle errors (e.g., show an error message)
      console.error("Error submitting the form:", error.message);
    } finally {
      setSubmitting(false);
    }
  };
  return (
    <>
    <h1>Add Issue</h1>
    
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={handleSubmit}
    >
      {({ isSubmitting }) => (
        <Form>
          {/* Text Input */}
          <div>
            <label htmlFor="textInput">Description</label>
            <Field type="text" id="IssueDescription" name="IssueDescription" />
            <ErrorMessage name="IssueDescription" component="div" className="abcd" />
            {/* {Formik.values} */}
          </div>


          {/* Selector (Dropdown) */}
          <div>
            <label htmlFor="selector">Selector:</label>
            <Field as="select" id="selector" name="Severity">
              <option value="">Select an option</option>
              <option value="Major">Major</option>
              <option value="Mino">Minor</option>
              <option value="Critical">Critical</option>
            </Field>
            <ErrorMessage name="Severity" component="div" />
          </div>
 
          {/* Radio Button */}
             <div>
            <label>
              <Field type="radio" name="Status" value="Open" />
              Open
            </label>
            <label>
              <Field type="radio" name="Status" value="In Progress" />
              In Progress
            </label>
            <label>
              <Field type="radio" name="Status" value="Closed" />
              Closed
            </label>
            <ErrorMessage name="Status" component="div" />
         
            </div>
             
          {/* Submit Button */}
          <div>
            <button className="button" type="submit" disabled={isSubmitting}>
              Submit
            </button>
          </div>
        </Form>
      )}
    </Formik>
    </>
  );
};

export default Addissue;
