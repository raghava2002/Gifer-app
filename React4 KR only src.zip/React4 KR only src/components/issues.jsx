
//import axios from 'axios';
import React from 'react';
//import './components/issue.css'
import './issue.css'

import { useState, useEffect } from 'react';
import axios from 'axios';
//import React from 'react'
//import React, { Component } from 'react'
import { Routes, Route } from 'react-router-dom';
import {Link,useNavigate} from 'react-router-dom'

import Addissue from './Addissue';

import Navbar from './Navbar';
import Details from './details';
import { UserProvider } from './useContext';

function Issues() {
  const [issues, setIssues] = useState([]);
  
  //const history=useHistory();

  useEffect(() => {
    axios.get('http://localhost:3000/issues').then((response) => {
      setIssues(response.data);
    });
  }, []);

let path=`/issues/${issues.IssueDescription}`;
const navigate=useNavigate()
 
  const handleLink=()=>{
    
    let x=confirm("Are you sure you want to view details");
    
    
    if(x){
     
      console.log(path);
      

    }
}

  return (
    <>
    <div>
      <h2>Issues List</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>IssueDescription</th>
            <th>Severity</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {issues.map((issue) => (
         
            <tr key={issue.id}>
              <td>{issue.id}</td>
              <td>
             
               <UserProvider>
             <Link onClick={handleLink} to={`/issues/${issue.IssueDescription}`}> {issue.IssueDescription}</Link>
             </UserProvider>
             
                </td>
              <td>{issue.Severity}</td>
              <td>{issue.Status}</td>
            </tr>
        ))} 
        </tbody>
      </table>
    </div>
    {/* <nav> */}
        <div className='add'>
        <Link to="/addissue">AddIssue</Link>
        </div>
        {/* </nav> */}
    </>
  );
}

export default Issues;