import React from 'react';




function About () {
  return (
 


<h2>About: This application is used to track the status of the issues raised</h2>)
}

export default About;