import React from 'react'
import {useParams,Link} from 'react-router-dom'
import { UserConsumer } from './useContext';





function details(){

    const param = useParams();
    const text=param.issue;
    return (

        <>
        <div>

           <UserConsumer>
            {
                discription=>{
                    return <h2>IssueDescription:{text}</h2>             }
            }
           </UserConsumer>

        </div>
        <div >
        <Link to="/issues">Back</Link></div>
       
        </>
    )

}


export default details